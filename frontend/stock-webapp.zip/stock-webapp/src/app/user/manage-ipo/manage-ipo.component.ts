import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'manage-ipo',
  templateUrl: './manage-ipo.component.html',
  styleUrls: ['./manage-ipo.component.css']
})
export class ManageIpoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
