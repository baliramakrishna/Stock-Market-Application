import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'compare-charts',
  templateUrl: './compare-charts.component.html',
  styleUrls: ['./compare-charts.component.css']
})
export class CompareChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
